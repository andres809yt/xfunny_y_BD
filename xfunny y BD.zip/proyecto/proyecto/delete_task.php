<?php

include("db.php");

if(isset($_GET['usuario'])) {
  $id = $_GET['usuario'];
  $query = "DELETE FROM registro WHERE usuario = $id";
  $result = mysqli_query($conn, $query);
  if(!$result) {
    die("Query Failed.");
  }

  $_SESSION['message'] = 'usuario eliminado exitosamente';
  $_SESSION['message_type'] = 'danger';
  header('Location: index.php');
}

?>