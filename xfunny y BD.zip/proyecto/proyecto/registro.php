<?php include("db.php"); ?>


<?php include('includes/header.php'); ?>

<main class="container p-4">
  <div class="row">
    <div class="col-md-3">
      <!-- MESSAGES -->

      <?php if (isset($_SESSION['message'])) { ?>
      <div class="alert alert-<?= $_SESSION['message_type']?> alert-dismissible fade show" role="alert">
        <?= $_SESSION['message']?>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <?php session_unset(); } ?>

      <!-- ADD TASK FORM -->
      <div class="card card-body">
        <form action="save_task.php" method="POST">
          <div class="form-group">
            <input type="text" name="email" class="form-control" placeholder="email" autofocus>
          </div>
          <div class="form-group">
            <input type="date" name="fechadenacimiento" class="form-control" placeholder="  fechadenacimiento"  autofocus>
          </div>
          <div class="form-group">
            <input type="text" name="usuario" class="form-control" placeholder="usuario" autofocus>
          </div>
          <div class="form-group">
            <input type="password" name="contraseña" class="form-control" placeholder=" contraseña " autofocus>
          </div>

          
          <button type="submit" class="btn btn-primary" name="Ingresar" <a href="http://localhost/proyecto/proyecto/login.php">Registrate</a></button>
        </form>
      </div>



    
      
    </div>
    <div class="col-md-9">
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>email</th>
            <th>fechadenacimiento</th>
            <th>usuario</th>
            <th>contraseña</th>
            <th>Editar/Borrar</th>
          </tr>
        </thead>
        <tbody>

          <?php
          $query = "SELECT * FROM registro";
          $result_tasks = mysqli_query($conn, $query);    

          while($row = mysqli_fetch_assoc($result_tasks)) { ?>
          <tr>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['fechadenacimiento']; ?></td>
            <td><?php echo $row['usuario']; ?></td>
            <td><?php echo $row['contraseña']; ?></td>
            
            <td>
              <a href="edit.php?usuario=<?php echo $row['usuario']?>" class="btn btn-secondary">
                <i class="fas fa-marker"></i>
              </a>
              <a href="delete_task.php?usuario=<?php echo $row['usuario']?>" class="btn btn-danger">
                <i class="far fa-trash-alt"></i>
              </a>
            </td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
    </div>
  </div>
</main>

<?php include('includes/footer.php'); ?>
